int mtu, interval;
char *pidfile, *user;

void config_database(char* filename);
void config_listeners(char* filename);
void config_other(char* filename);
