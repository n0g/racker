#define LOCAL_SERVER_PORT 1337 
#define IPV4HOST "0.0.0.0"
#define IPV6HOST "::"

//database access
#define DBSERVER "localhost"
#define DBUSER "user"
#define DBPWD "password"
#define DBDB "racker"

//don't touch these unless you know what you are doing (probably not)
#define INTERVAL 60
#define PIDFILE "/var/run/racker.pid"
#define USER "racker"
#define MAX_MSG 100
