/* racker.c
 *
 * racker (german: rascal, mischievous little kid)
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
 * UDP Bittorrent Tracker implemented after 
 * Olaf van der Spek Protocol Design
 * http://www.rasterbar.com/products/libtorrent/udp_tracker_protocol.html
 * http://xbtt.sourceforge.net/udp_tracker_protocol.html
 * http://www.bittorrent.org/beps/bep_0015.html
 * IPv6: http://opentracker.blog.h3q.com/2007/12/28/the-ipv6-situation/
 *
 * Author: Matthias Fassl <mf@x1598.at>
 * License: AFLv3
 *
 * Version: 0.01 (2009-Feb-01) shows Connection_id, action and Transaction_id of incoming requests
 * Version: 0.02 (2009-Mar-23) answers connect requests successfully
 * Version: 0.03 (2009-Mar-24) checks correct connection_id on connect and sends error messages
 * Version: 0.04 (2009-Mar-25) announce function can write new info into the database
 * Version: 0.10 (2009-Mar-26) announce works! tracker is functional
 *
 * Version: 0.11 (2009-Mar-27) storing ip in the systems byte order, fixed the amount of peers that are returned
 * Version: 0.12 (2009-Mar-30) database entries older than 2*INTERVAL get єrased automatically
 * Version: 0.13 (2009-Mar-30) the first іnfo_hash from scrape gets answered
 * Version: 0.14 (2009-Apr-03) scrape works for all info_hashes that are asked for - can't return num of completed yet
 * Version: 0.15 (2009-Apr-04) support for the ipv6 announce - no support for running the server on ipv6 YET
 * Version: 0.16 (2009-Apr-04) Everything gets logged to syslog, created init script, racker gets daemonized + drops root rights
 * Version: 0.20 (2009-Apr-05) IPv6 support (not yet fully tested) - code clean up, new structure, easy exchange of database backend possible
 *
 * TODO:	
 *
 * Nice-to-Haves
 * 		Authentication
 * 		Check if connection_id is known
 *
 * 		Database support for at least postgres (sqlite?)
 * 		using dynamic link loader (dlopen) to load the right shared object
 *
 * 		make nice debian package
 * 		write nice man page
 */
#include <sys/types.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <signal.h>
#include <syslog.h>

#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>

#include "config.h"
#include "actions.h"
#include "utils.h"
#include "net.h"
#include "database.h"

void read_config(char* filename);
char* get_config_file(int argc, char* argv[]);
void usage();
static void stackDump (lua_State *L);

int main(int argc, char *argv[]) {	

	pthread_t thread1, thread2;
	int  iret1, iret2;
	char* config;
	
	//open syslog
	openlog(argv[0], LOG_PID|LOG_CONS, LOG_DAEMON);
	syslog(LOG_INFO,"----- racker is starting -----");

	//read config file location from option
	config = get_config_file(argc,argv);	
	printf("Filename: %s\n",config);
	read_config(config);
	//fall to background
	//check for root rights
	//geuid() == 0
	//daemonize();
	//write_pid_file(PIDFILE,getpid());  

	//open listening sockets
	s6 = bind6(IPV6HOST,LOCAL_SERVER_PORT);
	if (s6 < 0) {
		syslog(LOG_ERR, "could not create listening socket");
	}
	s4 = bind4(IPV4HOST,LOCAL_SERVER_PORT);
	if (s4 < 0) {
		syslog(LOG_ERR, "could not create listening socket");
	}

	//install signal handler - clean closing on shutdown
	signal( SIGTERM, sig_handler );
	syslog(LOG_DEBUG,"Installed Signal Handler");

	//hand over root rights
	//drop_root_rights(USER);
	//connect to database
	connect_database();
	syslog(LOG_INFO,"waiting for data on port UDP %u",LOCAL_SERVER_PORT);
	//start threads that listen for data
	iret1 = pthread_create( &thread1, NULL, (void *)send_receive_loop4,(void *)s4);
     	iret2 = pthread_create( &thread2, NULL, (void *)send_receive_loop6,(void *)s6);

	pthread_join(thread1, NULL);
	pthread_join(thread2, NULL);
}

char* get_config_file(int argc, char* argv[]) {

	int c, file=-1;
	char *filename;
	extern char *optarg;
	extern int optind, optopt, opterr;

	while ((c = getopt(argc, argv, ":vf:")) != -1) {
    		switch(c) {
    			case 'v':
        			printf("racker Version 0.2 - Matthias Fassl\n");
        			break;
    			case 'f':
        			filename = optarg;
				file++;
        			break;
   			 case ':':
				usage();
    			case '?':
				usage();
    		}
	}

	if(file<0) 
		usage();	

	return filename;
}

void usage() {

	printf("Usage:\n\n");
	printf("'racker -v' for Version\n");
	printf("'rakcer -f /path/to/racker.conf' to start daemon\n");
	exit(1);
}

void read_config(char* filename) {
	//TODO: read all variables and make syntox error handler

	lua_State* L;

	char *pidfile, *user;
	
	/* initialize Lua */
	L = lua_open();
	/* load Lua base libraries */
	lua_baselibopen(L);
	/* load the script */
	lua_dofile(L, filename);
	/* the function name */
	lua_getglobal(L, "others");
	lua_pushstring(L, "pidfile");
	lua_gettable(L, -2);
 	if (!lua_isstring(L, -1))
        	error(L, "`pidfile' should be a string\n");

      	pidfile = (char *)lua_tostring(L, -1);
	
	lua_pushstring(L,"user");
	lua_gettable(L,-3);
 	if (!lua_isstring(L, -1))
        	error(L, "`user' should be a string\n");

      	user = (char *)lua_tostring(L, -1);
	stackDump(L);	
    
	/* print the result */
	printf( "The result is %s, and %s\n", pidfile, user );

	/* cleanup Lua */
	lua_close(L);

}

 static void stackDump (lua_State *L) {
      int i;
      int top = lua_gettop(L);
      for (i = 1; i <= top; i++) {  /* repeat for each level */
        int t = lua_type(L, i);
        switch (t) {
    
          case LUA_TSTRING:  /* strings */
            printf("`%s'", lua_tostring(L, i));
            break;
    
          case LUA_TBOOLEAN:  /* booleans */
            printf(lua_toboolean(L, i) ? "true" : "false");
            break;
    
          case LUA_TNUMBER:  /* numbers */
            printf("%g", lua_tonumber(L, i));
            break;
    
          default:  /* other values */
            printf("%s", lua_typename(L, t));
            break;
    
        }
        printf("  ");  /* put a separator */
      }
      printf("\n");  /* end the listing */
    }

