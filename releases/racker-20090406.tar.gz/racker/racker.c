/* racker.c
 *
 * racker (german: rascal, mischievous little kid)
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
 * UDP Bittorrent Tracker implemented after 
 * Olaf van der Spek Protocol Design
 * http://www.rasterbar.com/products/libtorrent/udp_tracker_protocol.html
 * http://xbtt.sourceforge.net/udp_tracker_protocol.html
 * http://www.bittorrent.org/beps/bep_0015.html
 * IPv6: http://opentracker.blog.h3q.com/2007/12/28/the-ipv6-situation/
 *
 * Author: Matthias Fassl <mf@x1598.at>
 * License: AFLv3
 *
 * Version: 0.01 (2009-Feb-01) shows Connection_id, action and Transaction_id of incoming requests
 * Version: 0.02 (2009-Mar-23) answers connect requests successfully
 * Version: 0.03 (2009-Mar-24) checks correct connection_id on connect and sends error messages
 * Version: 0.04 (2009-Mar-25) announce function can write new info into the database
 * Version: 0.10 (2009-Mar-26) announce works! tracker is functional
 *
 * Version: 0.11 (2009-Mar-27) storing ip in the systems byte order, fixed the amount of peers that are returned
 * Version: 0.12 (2009-Mar-30) database entries older than 2*INTERVAL get єrased automatically
 * Version: 0.13 (2009-Mar-30) the first іnfo_hash from scrape gets answered
 * Version: 0.14 (2009-Apr-03) scrape works for all info_hashes that are asked for - can't return num of completed yet
 * Version: 0.15 (2009-Apr-04) support for the ipv6 announce - no support for running the server on ipv6 YET
 * Version: 0.16 (2009-Apr-04) Everything gets logged to syslog, created init script, racker gets daemonized + drops root rights
 * Version: 0.20 (2009-Apr-05) IPv6 support (not yet fully tested) - code clean up, new structure, easy exchange of database backend possible
 *
 * TODO:	
 *		read config variables from /etc/default
 *		getopt
 *
 * Nice-to-Haves
 * 		Authentication
 * 		Database support for at least postgres (sqlite?) - using #ifdefs
 * 		Check if connection_id is known
 */
#include <sys/types.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <signal.h>
#include <syslog.h>

#include "config.h"
#include "actions.h"
#include "utils.h"
#include "net.h"
#include "database.h"

int main(int argc, char *argv[]) {	

	pthread_t thread1, thread2;
	int  iret1, iret2;
	
	//open syslog
	openlog(argv[0], LOG_PID|LOG_CONS, LOG_DAEMON);
	syslog(LOG_INFO,"----- racker is starting -----");
	//fall to background
	daemonize();
	write_pid_file(PIDFILE,getpid());  

	//open listening sockets
	s6 = bind6(IPV6HOST,LOCAL_SERVER_PORT);
	if (s6 < 0) {
		syslog(LOG_ERR, "could not create listening socket");
	}
	s4 = bind4(IPV4HOST,LOCAL_SERVER_PORT);
	if (s4 < 0) {
		syslog(LOG_ERR, "could not create listening socket");
	}

	//install signal handler - clean closing on shutdown
	signal( SIGTERM, sig_handler );
	syslog(LOG_DEBUG,"Installed Signal Handler");

	//hand over root rights
	drop_root_rights(USER);
	//connect to database
	connect_database();
	syslog(LOG_INFO,"waiting for data on port UDP %u",LOCAL_SERVER_PORT);
	//start threads that listen for data
	iret1 = pthread_create( &thread1, NULL, (void *)send_receive_loop4,(void *)s4);
     	iret2 = pthread_create( &thread2, NULL, (void *)send_receive_loop6,(void *)s6);

	pthread_join(thread1, NULL);
	pthread_join(thread2, NULL);
}
