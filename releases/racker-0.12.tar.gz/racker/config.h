#define LOCAL_SERVER_PORT 1337 
#define MAX_MSG 100
#define DBSERVER "localhost"
#define DBUSER "root"
#define DBPWD "letmein"
#define DBDB "racker"
#define INTERVAL 600
