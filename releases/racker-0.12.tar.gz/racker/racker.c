/* racker.c
 *
 * racker (german: rascal, mischievous little kid)
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
 * UDP Bittorrent Tracker implemented after 
 * Olaf van der Spek Protocol Design
 * http://www.rasterbar.com/products/libtorrent/udp_tracker_protocol.html
 * http://xbtt.sourceforge.net/udp_tracker_protocol.html
 * http://www.bittorrent.org/beps/bep_0015.html
 *
 * Author: Matthias Fassl
 * License: AFLv3
 *
 * Version: 0.01 (2009-Feb-01) shows Connection_id, action and Transaction_id of incoming requests
 * Version: 0.02 (2009-Mar-23) answers connect requests successfully
 * Version: 0.03 (2009-Mar-24) checks correct connection_id on connect and sends error messages
 * Version: 0.04 (2009-Mar-25) announce function can write new info into the database
 * Version: 0.10 (2009-Mar-26) announce works! tracker is functional
 * Version: 0.11 (2009-Mar-27) storing ip in the systems byte order, fixed the amount of peers that are returned
 *
 */
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <byteswap.h>
#include <endian.h>
#include <time.h>
#include <mysql.h>

#include "config.h"

void connect_request(uint64_t,uint32_t);
void announce(uint64_t,uint32_t,char[]);
void scrape(uint64_t,uint32_t,char[]);
void error(uint32_t,char*);
uint64_t generate_connection_id();
void connect_database();
char* strToHexStr(char*,int);

int sd, rc, n, cliLen;
struct sockaddr_in cliAddr, servAddr;
MYSQL *conn;

int main(int argc, char *argv[]) {
   
	char msg[MAX_MSG];

	/* socket creation */
	sd=socket(AF_INET, SOCK_DGRAM, 0);
	if(sd<0) {
		printf("%s: cannot open socket \n",argv[0]);
		return 1;
	}

	/* bind local server port */
	servAddr.sin_family = AF_INET;
	servAddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servAddr.sin_port = htons(LOCAL_SERVER_PORT);
	rc = bind (sd, (struct sockaddr *) &servAddr,sizeof(servAddr));
	if(rc<0) {
		printf("%s: cannot bind port number %d \n", argv[0], LOCAL_SERVER_PORT);
		return 1;
	}

	connect_database();
	printf("%s: waiting for data on port UDP %u\n", argv[0],LOCAL_SERVER_PORT);

	/* server infinite loop */
	while(1) {
      
		/* init buffer */
		memset(msg,0x0,MAX_MSG);

		/* receive message */
		cliLen = sizeof(cliAddr);
		n = recvfrom(sd, msg, MAX_MSG, 0, (struct sockaddr *) &cliAddr, &cliLen);

		if(n<0) {
			printf("%s: cannot receive data \n",argv[0]);
			continue;
		}
      
		uint64_t connection_id;
		int32_t action;
		uint32_t transaction_id;

		//print senders address and port
		printf("\nClient IP: %s\n", inet_ntoa(cliAddr.sin_addr)); 
		printf("Client Port: %hu\n", ntohs(cliAddr.sin_port));
		//get basic protocol details from client
		memcpy(&connection_id,msg,8);
		memcpy(&action,msg+8,4);
		memcpy(&transaction_id,msg+12,4);
	
		//convert them to host order
		#ifdef LITTLE_ENDIAN
		connection_id = bswap_64(connection_id);
		action = bswap_32(action);
		transaction_id = bswap_32(transaction_id);
		#endif

		switch( action ) {

			case 0: printf("CONNECT\n");
				connect_request(connection_id,transaction_id);
				break;

			case 1: printf("ANNOUNCE\n");
				announce(connection_id,transaction_id,msg);
				break;

			case 2: printf("SCRAPE\n");
				scrape(connection_id,transaction_id,msg);
				break;

			default: printf("Didn't recognize Action.");

		}
	}/*end of server infinite loop */
	
	return 0;
}

void connect_request(uint64_t connection_id, uint32_t transaction_id) {

	int32_t action;
	action = 0;

	//will be 0x41727101980 (network order) on connect 
	//4497486125440 in decimal
	if( connection_id != 4497486125440LLU ) {

		error(transaction_id, "Wrong connection_id on first connect.");
		return;
	}
	printf("\tConnection id: %lld\n",connection_id);
	//TODO: save this generated connection id + transaction id in database
 	connection_id = generate_connection_id();
	printf("\tTransaction id: %u\n",transaction_id);
	printf("\tgenerated Connection ID: %lld\n",connection_id);

	//convert them to network order
	#ifdef LITTLE_ENDIAN
	connection_id = bswap_64(connection_id);
	action = bswap_32(action);
	transaction_id = bswap_32(transaction_id);
	#endif

	//answer
	char *sbuffer;
	sbuffer = malloc(16);
	memcpy(sbuffer,&action,4);
	memcpy(sbuffer+4,&transaction_id,4);
	memcpy(sbuffer+8,&connection_id,8); 
	sendto(sd,sbuffer,16,0,(struct sockaddr *) &cliAddr,sizeof(cliAddr));
}

void announce(uint64_t connection_id, uint32_t transaction_id, char msg[]) {
	
	//TODO: check if connection_id is known

	char info_hash[20], peer_id[20];
	char *info_hash_hex, *peer_id_hex,*sbuffer;
	int64_t downloaded,left,uploaded;
	int32_t event,num_want,num_peers,action,interval,sbufLen;
	uint32_t ip, key, seeders, leechers;	
	uint16_t port, extensions;
	MYSQL_RES *res;
	MYSQL_ROW row;
	char* query = malloc(500);

	memcpy(&info_hash,msg+16,20);
	memcpy(&peer_id,msg+36,20);
	memcpy(&downloaded,msg+56,8);
	memcpy(&left,msg+64,8);
	memcpy(&uploaded,msg+72,8);
	memcpy(&event,msg+80,4);
	memcpy(&ip,msg+84,4);
	memcpy(&key,msg+88,4);
	memcpy(&num_want,msg+92,4);
	memcpy(&port,msg+96,2);
	memcpy(&extensions,msg+98,2);
	
	//replace 0 (default) ip with the real ip address
	if(ip==0) {
		ip = cliAddr.sin_addr.s_addr;		
	}

	#ifdef LITTLE_ENDIAN
	downloaded = bswap_64(downloaded);
	left = bswap_64(left);
	uploaded = bswap_64(uploaded);
	event = bswap_32(event);
	ip = bswap_32(ip);
	key = bswap_32(key);
	num_want = bswap_32(num_want);
	port = bswap_16(port);
	extensions = bswap_16(extensions);
	#endif
	
	//convert info_hash and peer_id to hex so that they are printable
	info_hash_hex = strToHexStr(info_hash,20);
	peer_id_hex = strToHexStr(peer_id,20);

	printf("\tConnection ID: %lld\n",connection_id);
	printf("\tInfo Hash: %s\n\tPeer ID: %s\n",info_hash_hex, peer_id_hex);
	printf("\tDownloaded: %lld\n\tLeft: %lld\n\tUploaded: %lld\n",downloaded,left,uploaded);
	printf("\tEvent: %u\n\tNumber of Peers wanted: %u\n",event, num_want);


	//check if peer has already announced
	sprintf(query,"SELECT COUNT(*) FROM peers WHERE infohash='%s' AND peerid='%s'",info_hash_hex,peer_id_hex);
	printf("\t%s\n",query);
        if (mysql_query(conn, query)) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                exit(1);
        }
        res = mysql_use_result(conn);
        row = mysql_fetch_row(res);

        //update entry if peer has announced already
        if(*row[0]=='1') {
        	sprintf(query,"UPDATE peers SET ts=NOW(),downloaded=%lld,bleft=%lld,uploaded=%lld,ip=%u,idkey=%u,port=%d WHERE infohash='%s' and peerid='%s'",downloaded,left,uploaded,ip,key,port,info_hash_hex,peer_id_hex);
        }
        //or insert the new infos if peer hasn't announced until now
        else {
        	sprintf(query,"INSERT INTO peers VALUES(CURRENT_TIMESTAMP,'%s','%s',%lld,%lld,%lld,%u,%u,%d)",info_hash_hex,peer_id_hex,downloaded,left,uploaded,ip,key,port);
        }
        //execute query
        mysql_free_result(res);
        printf("\t%s\n",query);
        if (mysql_query(conn, query)) {
        	fprintf(stderr, "%s\n", mysql_error(conn));
                exit(1);
        }

	//delet old peers from database
	sprintf(query,"DELETE FROM peers WHERE TIMESTAMPDIFF(MINUTE,ts,NOW())>20");
	printf("\t%s\n",query);
        if (mysql_query(conn, query)) {
                fprintf(stderr, "%s\n", mysql_error(conn));
                exit(1);
        }

        //Get number of seeders and leechers
	sprintf(query,"SELECT COUNT(*) AS 'Seeders',(SELECT COUNT(*) FROM peers WHERE bleft!=0 AND infohash='%s') AS 'Leechers' FROM peers WHERE bleft=0 AND infohash='%s'",info_hash_hex,info_hash_hex);
	printf("\t%s\n",query);
	if (mysql_query(conn,query)) {
		fprintf(stderr, "%s\n",mysql_error(conn));
		exit(1);
	}
	res = mysql_use_result(conn);
	row = mysql_fetch_row(res);
	seeders = atoi(row[0]);
	leechers = atoi(row[1]);	
	mysql_free_result(res);

	//get data of the peers from the database
	sprintf(query,"SELECT ip,port FROM peers WHERE infohash='%s' ORDER BY RAND() LIMIT %u",info_hash_hex,num_want);
	printf("\t%s\n",query);
	if (mysql_query(conn, query)) {
		fprintf(stderr, "%s\n", mysql_error(conn));
		exit(1);
	}
	res = mysql_store_result(conn);
	num_peers = mysql_num_rows(res);


	sbufLen = 20+num_peers*6;
	sbuffer = malloc(sbufLen);
	action = 1;
	interval = INTERVAL;	
	
	#ifdef LITTLE_ENDIAN
	action = bswap_32(action);
	interval = bswap_32(interval);
	transaction_id = bswap_32(transaction_id);
	seeders = bswap_32(seeders);
	leechers = bswap_32(leechers);	
	#endif

	memcpy(sbuffer,&action,4);
	memcpy(sbuffer+4,&transaction_id,4);
	memcpy(sbuffer+8,&interval,4);
	memcpy(sbuffer+12,&leechers,4);
	memcpy(sbuffer+16,&seeders,4);

	int i;
	printf("\tNumber of Peers available: %u\n",num_peers);
	for(i=0;i<num_peers;i++) {

		row = mysql_fetch_row(res);

		ip = atoi(row[0]);
		port = atoi(row[1]);

		printf("\t%u %u\n",ip,port);
			
		#ifdef LITTLE_ENDIAN
		ip = bswap_32(ip);
		port = bswap_16(port);
		#endif
		
		memcpy(sbuffer+20+i*6,&ip,4);
		memcpy(sbuffer+24+i*6,&port,2);
	}
	mysql_free_result(res);

	sendto(sd,sbuffer,sbufLen,0,(struct sockaddr *) &cliAddr,sizeof(cliAddr));
}

void scrape(uint64_t connection_id, uint32_t transaction_id, char msg[]) {
	
	//TODO: check if connection_id and transaction_id is known
	//TODO: read following stuff from incoming msg
	
	/*
	Client sends packet:
	size 	name 	description
	int64_t 	connection_id 	The connection id retreived from the establishing of the connection.
	int32_t 	action 	The action, in this case, 2 for scrape. See actions.
	int32_t 	transaction_id 	Randomized by client.

	The following structure is repeated for each info-hash to scrape, but limited by the MTU.
	size 	name 	description
	int8_t[20] 	info_hash 	The info hash that is to be scraped.
	*/

	//TODO: read necessary information from database
	//TODO: Send reply with following arguments
	
	/*
	Server replies with packet:
	size 	name 	description
	int32_t 	action 	The action, should in this case be 2 for scrape. If 3 (for error) see errors.
	int32_t 	transaction_id 	Must match the sent transaction id.

	The rest of the packet contains the following structures once for each info-hash you asked in the scrape request.
	size 	name 	description
	int32_t 	complete 	The total number of completed downloads.
	int32_t 	downloaded 	The current number of connected seeds.
	int32_t 	incomplete 	The current number of connected leechers.
	*/
}

void error(uint32_t transaction_id,char* error_msg) {

	int32_t action;
	char *sbuffer;
	int msgLen, bufLen;

	action=3;
	msgLen = strlen(error_msg);
	bufLen = msgLen+8;
	sbuffer = malloc(bufLen);

	//convert them to network order
	#ifdef LITTLE_ENDIAN
	action = bswap_32(action);
	transaction_id = bswap_32(transaction_id);
	#endif		

	memcpy(sbuffer,&action,4);
	memcpy(sbuffer+4,&transaction_id,4);
	memcpy(sbuffer+8,&error_msg,msgLen);
	
	printf("ERROR\n\tTransaction ID: %u\n\t Text: %s\n",transaction_id,error_msg);
	sendto(sd,sbuffer,bufLen,0,(struct sockaddr *) &cliAddr,sizeof(cliAddr));
}

uint64_t generate_connection_id() {

	uint64_t connection_id;
 	uint32_t tmp;
	
	srand((unsigned) time(NULL)); 		
	tmp = rand();
	memcpy(&connection_id,&tmp,4);
	tmp = rand();
	memcpy(((char*)(&connection_id))+4,&tmp,4);

	return connection_id;
}

void connect_database() {
	
	conn = mysql_init(NULL);

	/* Connect to database */
	if (!mysql_real_connect(conn, DBSERVER, DBUSER, DBPWD, DBDB, 0, NULL, 0)) {
		fprintf(stderr, "%s\n", mysql_error(conn));
		exit(1);
	}
	if(conn != NULL) {
		printf("Database Connection established\n");
	}
}

char* strToHexStr(char* str, int len)
{
        char *newstr = malloc(len*2+1);
	mysql_hex_string(newstr,str,len);
	return(newstr);
}
