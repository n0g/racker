#define LOCAL_SERVER_PORT 1337 
#define MAX_MSG 100
#define DBSERVER "localhost"
#define DBUSER "user"
#define DBPWD "password"
#define DBDB "racker"
#define INTERVAL 600
