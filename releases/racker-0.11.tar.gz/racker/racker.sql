DROP DATABASE IF EXISTS racker;
CREATE DATABASE racker;
USE racker;

DROP TABLE IF EXISTS peers;
CREATE TABLE peers (
	infohash	VARCHAR(40), 
	peerid 		VARCHAR(40), 
	downloaded 	BIGINT UNSIGNED, 
	bleft 		BIGINT UNSIGNED, 
	uploaded 	BIGINT UNSIGNED, 
	ip 		INT UNSIGNED, 
	idkey 		INT UNSIGNED, 
	port 		SMALLINT UNSIGNED,
	PRIMARY KEY(infohash,peerid)
	);
